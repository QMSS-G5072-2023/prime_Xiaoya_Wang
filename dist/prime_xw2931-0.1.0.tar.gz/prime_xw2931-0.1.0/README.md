# prime_xw2931

Python package that eases the pain of concatenating Pandas categoricals!

## Installation

```bash
$ pip install prime_xw2931
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`prime_xw2931` was created by Xiaoya Wang. It is licensed under the terms of the MIT license.

## Credits

`prime_xw2931` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
